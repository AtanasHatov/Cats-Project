﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CatsProject.Data.Migrations
{
    /// <inheritdoc />
    public partial class CatsBD2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Cats_Breeds_breedId",
                table: "Cats");

            migrationBuilder.RenameColumn(
                name: "breedId",
                table: "Cats",
                newName: "BreedId");

            migrationBuilder.RenameIndex(
                name: "IX_Cats_breedId",
                table: "Cats",
                newName: "IX_Cats_BreedId");

            migrationBuilder.AddForeignKey(
                name: "FK_Cats_Breeds_BreedId",
                table: "Cats",
                column: "BreedId",
                principalTable: "Breeds",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Cats_Breeds_BreedId",
                table: "Cats");

            migrationBuilder.RenameColumn(
                name: "BreedId",
                table: "Cats",
                newName: "breedId");

            migrationBuilder.RenameIndex(
                name: "IX_Cats_BreedId",
                table: "Cats",
                newName: "IX_Cats_breedId");

            migrationBuilder.AddForeignKey(
                name: "FK_Cats_Breeds_breedId",
                table: "Cats",
                column: "breedId",
                principalTable: "Breeds",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
