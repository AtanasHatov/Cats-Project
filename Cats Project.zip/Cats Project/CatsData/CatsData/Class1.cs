﻿namespace CatsData
{
    public class Class1
    {

    }
}
