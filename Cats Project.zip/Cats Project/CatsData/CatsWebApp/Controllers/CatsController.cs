﻿using CatsProject.Data;
using CatsProject.Data.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace CatsProject.Web.Controllers
{
    public class CatsController : Controller
    {
        private readonly CatContext context;

        public CatsController(CatContext _context)
        {
            context = _context;
        }

        public async Task<IActionResult> Index(Guid id)
        {
            var cats = await context.Cats.Include(c => c.breed).ToListAsync();
            return View(cats);
        }

        [HttpGet]
        public async Task<IActionResult> Create()
        {
            var brreds = await context.Breeds.ToListAsync();
            ViewBag.Breeds = new SelectList(brreds, "Id", "Name");
            return View();

        }
        [HttpPost]
        public async Task<IActionResult> Create(Cat cat)
        {
            context.Cats.Add(cat);
            await context.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> Edit(Guid id)
        {
            var cat = await context.Cats.FindAsync(id);
            ViewBag.Breeds = new SelectList(context.Breeds, "Id", "Name", cat.BreedId);
            return View(cat);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(Cat cat)
        {
            //context.Employees.Update(model);
            //await context.SaveChangesAsync();
            //return RedirectToAction("Index");
            context.Cats.Update(cat);
            await context.SaveChangesAsync();
            return RedirectToAction("Index");
        }


        [HttpPost]
        public async Task<IActionResult> Delete(Guid Id)
        {
            var cat = await context.Cats.FirstOrDefaultAsync(a => a.Id == Id);
            if (cat == null)
            {
                return NotFound();
            }
            context.Cats.Remove(cat);
            await context.SaveChangesAsync();

            return RedirectToAction("Index");
        }

    }
}
