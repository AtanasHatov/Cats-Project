﻿using CatsProject.Data;
using CatsProject.Data.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CatsProject.Web.Controllers
{
    public class BreedsController : Controller
    {
        private readonly CatContext context;

        public BreedsController(CatContext _context)
        {
            context = _context;
        }
      
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(Breed breed)
        {

            context.Breeds.Add(breed);
            await context.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Index(Guid id)
        {
            var breeds = await context.Breeds.ToListAsync();
            return View(breeds);
        }

        [HttpPost]
        public async Task<IActionResult> Delete(Guid Id)
        {
            var breed=await context.Breeds.FirstOrDefaultAsync(a=>a.Id==Id);
            if (breed==null)
            {
                return NotFound();
            }
            context.Breeds.Remove(breed);
            await context.SaveChangesAsync();

            return RedirectToAction("Index");
        }
    }
}
